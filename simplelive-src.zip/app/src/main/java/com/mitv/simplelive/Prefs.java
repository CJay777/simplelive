package com.mitv.simplelive;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {

    public static final String DEFAULT_SOURCE = "http://192.168.5.31:28080/channels.m3u";

    private static SharedPreferences sp(Context context) {
        return context.getSharedPreferences("simplelive", Context.MODE_PRIVATE);
    }

    public static String source(Context context) {
        return sp(context).getString("source", DEFAULT_SOURCE);
    }

    public static void setSource(Context context, String value) {
        sp(context).edit().putString("source", value).apply();
    }

    public static boolean preloadPrev(Context context) {
        return sp(context).getBoolean("preload_prev", true);
    }

    public static void setPreloadPrev(Context context, boolean value) {
        sp(context).edit().putBoolean("preload_prev", value).apply();
    }

    public static boolean preload(Context context) {
        return sp(context).getBoolean("preload", true);
    }

    public static void setPreload(Context context, boolean value) {
        sp(context).edit().putBoolean("preload", value).apply();
    }

    public static String lastUrl(Context context) {
        return sp(context).getString("last_url", "");
    }

    public static void setLastUrl(Context context, String value) {
        sp(context).edit().putString("last_url", value).apply();
    }
}
