package com.mitv.simplelive;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.media3.ui.PlayerView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements LiveController.Listener {

    private PlayerView playerA;
    private PlayerView playerB;
    private PlayerView playerC;
    private LinearLayout panel;
    private ListView listView;
    private View infoBar;
    private TextView infoName;
    private View loading;
    private TextView toast;
    private LinearLayout switchOverlay;
    private TextView switchName;

    private LiveController controller;
    private ChannelAdapter adapter;
    private final List<Channel> channels = new ArrayList<>();
    private int index;
    private int lineRetry;
    private boolean panelVisible;
    private boolean loaded;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable hideInfoTask;
    private Runnable hideToastTask;
    private AlertDialog dialog;
    private long lastBackTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hideSystemUi();
        playerA = findViewById(R.id.player_a);
        playerB = findViewById(R.id.player_b);
        playerC = findViewById(R.id.player_c);
        panel = findViewById(R.id.panel);
        listView = findViewById(R.id.channel_list);
        infoBar = findViewById(R.id.info_bar);
        infoName = findViewById(R.id.info_name);
        loading = findViewById(R.id.loading);
        toast = findViewById(R.id.toast);
        switchOverlay = findViewById(R.id.switch_overlay);
        switchName = findViewById(R.id.switch_name);

        controller = new LiveController(this, playerA, playerB, playerC, this);
        adapter = new ChannelAdapter(this, channels);
        listView.setAdapter(adapter);
        listView.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                adapter.setSelected(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        listView.setOnItemClickListener((parent, view, position, id) -> {
            index = position;
            hidePanel();
            Channel channel = channels.get(position);
            controller.play(channel);
            showInfo(channel);
        });

        loadChannels();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void loadChannels() {
        String cached = readCache();
        if (cached != null) {
            List<Channel> list = M3uParser.parse(cached);
            if (!list.isEmpty()) {
                applyChannels(list);
                refreshChannels();
                return;
            }
        }
        showToast("正在加载频道…");
        refreshChannels();
    }

    private void refreshChannels() {
        String source = Prefs.source(this);
        new Thread(() -> {
            try {
                String text = Net.fetch(source);
                writeCache(text);
                List<Channel> list = M3uParser.parse(text);
                runOnUiThread(() -> {
                    if (channels.isEmpty()) applyChannels(list);
                    else updateChannels(list);
                });
            } catch (Exception e) {
                if (channels.isEmpty()) runOnUiThread(() -> showToast("加载失败：" + e.getMessage()));
            }
        }).start();
    }

    private void updateChannels(List<Channel> list) {
        if (list.isEmpty()) return;
        String current = channels.isEmpty() ? "" : channels.get(index).name;
        channels.clear();
        channels.addAll(list);
        int target = 0;
        for (int i = 0; i < channels.size(); i++) {
            if (channels.get(i).name.equals(current)) {
                target = i;
                break;
            }
        }
        index = target;
        adapter.notifyDataSetChanged();
    }

    private String readCache() {
        try {
            File file = new File(getFilesDir(), "channels.m3u");
            if (!file.exists()) return null;
            try (FileInputStream in = new FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = in.read(buffer)) > 0) out.write(buffer, 0, read);
                return out.toString("UTF-8");
            }
        } catch (Exception e) {
            return null;
        }
    }

    private void writeCache(String text) {
        try {
            File file = new File(getFilesDir(), "channels.m3u");
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write(text.getBytes("UTF-8"));
            }
        } catch (Exception ignored) {
        }
    }

    private void applyChannels(List<Channel> list) {
        channels.clear();
        channels.addAll(list);
        adapter.notifyDataSetChanged();
        if (channels.isEmpty()) {
            showToast("没有频道。按菜单键进入设置。");
            return;
        }
        int start = 0;
        String last = Prefs.lastName(this);
        for (int i = 0; i < channels.size(); i++) {
            if (channels.get(i).name.equals(last)) {
                start = i;
                break;
            }
        }
        index = start;
        loaded = true;
        controller.playFirst(channels.get(start));
        showInfo(channels.get(start));
    }

    private void move(int delta) {
        if (!loaded || channels.isEmpty()) return;
        int size = channels.size();
        index = ((index + delta) % size + size) % size;
        lineRetry = 0;
        Channel channel = channels.get(index);
        controller.play(channel);
        showInfo(channel);
    }

    private void switchLine(int delta) {
        if (!loaded || channels.isEmpty()) return;
        Channel channel = channels.get(index);
        if (!channel.hasMultipleLines()) {
            showToast("该频道只有一条线路");
            return;
        }
        lineRetry = 0;
        if (delta > 0) channel.nextLine();
        else channel.prevLine();
        controller.play(channel);
        showInfo(channel);
    }

    private void preloadAround() {
        if (!loaded || channels.isEmpty() || !Prefs.preload(this)) return;
        int size = channels.size();
        if (size < 2) return;
        int next = (index + 1) % size;
        int prev = (index - 1 + size) % size;
        Channel nextChannel = next == index ? null : channels.get(next);
        Channel prevChannel = (prev == index || !Prefs.preloadPrev(this)) ? null : channels.get(prev);
        controller.preload(prevChannel, nextChannel);
    }

    private void showInfo(Channel channel) {
        String text = channel.name;
        if (channel.hasMultipleLines()) text += "   线路 " + (channel.lineIndex() + 1) + "/" + channel.lineCount();
        infoName.setText(text);
        infoBar.setVisibility(View.VISIBLE);
        if (hideInfoTask != null) handler.removeCallbacks(hideInfoTask);
        hideInfoTask = () -> infoBar.setVisibility(View.GONE);
        handler.postDelayed(hideInfoTask, 3000);
    }

    private void showToast(String text) {
        toast.setText(text);
        toast.setVisibility(View.VISIBLE);
        if (hideToastTask != null) handler.removeCallbacks(hideToastTask);
        hideToastTask = () -> toast.setVisibility(View.GONE);
        handler.postDelayed(hideToastTask, 3500);
    }

    private void showPanel() {
        if (!loaded) return;
        panelVisible = true;
        adapter.setSelected(index);
        panel.setVisibility(View.VISIBLE);
        listView.requestFocus();
        listView.setSelection(index);
    }

    private void hidePanel() {
        panelVisible = false;
        panel.setVisibility(View.GONE);
    }

    private void openSetting() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        input.setSingleLine(true);
        input.setText(Prefs.source(this));
        input.setSelection(input.getText().length());
        CheckBox box = new CheckBox(this);
        box.setText("同时预载上一个频道（换台更快，更费流量）");
        box.setChecked(Prefs.preloadPrev(this));
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(56, 28, 56, 8);
        layout.addView(input);
        layout.addView(box);
        dialog = new AlertDialog.Builder(this)
                .setTitle("设置")
                .setView(layout)
                .setPositiveButton("保存并重载", (d, which) -> {
                    String value = input.getText().toString().trim();
                    Prefs.setPreloadPrev(this, box.isChecked());
                    if (value.isEmpty()) return;
                    Prefs.setSource(this, value);
                    new File(getFilesDir(), "channels.m3u").delete();
                    loaded = false;
                    loadChannels();
                })
                .setNegativeButton("取消", null)
                .create();
        dialog.setOnShowListener(d -> {
            if (dialog != null && dialog.getButton(DialogInterface.BUTTON_POSITIVE) != null) {
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).requestFocus();
            }
        });
        dialog.setOnDismissListener(d -> dialog = null);
        dialog.show();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            int code = event.getKeyCode();
            if (dialog != null && dialog.isShowing()) {
                if (code == KeyEvent.KEYCODE_BACK) {
                    dialog.dismiss();
                    return true;
                }
                return super.dispatchKeyEvent(event);
            }
            if (panelVisible) {
                if (code == KeyEvent.KEYCODE_BACK) {
                    hidePanel();
                    return true;
                }
                if (code == KeyEvent.KEYCODE_MENU) {
                    hidePanel();
                    openSetting();
                    return true;
                }
                return super.dispatchKeyEvent(event);
            }
            switch (code) {
                case KeyEvent.KEYCODE_DPAD_UP:
                    move(-1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                    move(1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    switchLine(-1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    switchLine(1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                    showPanel();
                    return true;
                case KeyEvent.KEYCODE_MENU:
                    openSetting();
                    return true;
                case KeyEvent.KEYCODE_BACK:
                    long now = System.currentTimeMillis();
                    if (now - lastBackTime < 2000) {
                        finish();
                    } else {
                        lastBackTime = now;
                        showToast("再按一次返回退出");
                    }
                    return true;
                default:
                    break;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (controller != null) controller.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (controller != null) controller.resume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (controller != null) controller.release();
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onChannelPlayed(Channel channel) {
        lineRetry = 0;
        Prefs.setLastName(this, channel.name);
        showInfo(channel);
        preloadAround();
    }

    @Override
    public void onLoading(boolean visible) {
        loading.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (!visible) switchOverlay.setVisibility(View.GONE);
    }

    @Override
    public void onSwitching(Channel channel) {
        switchName.setText(channel.name);
        switchOverlay.setVisibility(View.VISIBLE);
    }

    @Override
    public void onError(String message) {
        loading.setVisibility(View.GONE);
        switchOverlay.setVisibility(View.GONE);
        if (loaded && !channels.isEmpty()) {
            Channel channel = channels.get(index);
            if (lineRetry < channel.lineCount() - 1) {
                lineRetry++;
                channel.nextLine();
                showToast("线路 " + (channel.lineIndex() + 1) + " 失败，自动换线重试…");
                controller.play(channel);
                return;
            }
        }
        lineRetry = 0;
        showToast("播放失败：" + message);
    }
}
