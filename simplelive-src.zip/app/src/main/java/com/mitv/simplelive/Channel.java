package com.mitv.simplelive;

import java.util.ArrayList;
import java.util.List;

/**
 * 一个频道。同名频道在解析时被合并，多个源作为「线路」保存在 urls 里。
 */
public class Channel {

    public final String name;
    public final String group;
    public final String logo;
    private final List<String> urls = new ArrayList<>();
    private int lineIndex;

    public Channel(String name, String group, String logo) {
        this.name = name == null ? "" : name;
        this.group = group == null ? "" : group;
        this.logo = logo == null ? "" : logo;
    }

    public void addUrl(String url) {
        if (url == null) return;
        String value = url.trim();
        if (value.isEmpty() || urls.contains(value)) return;
        urls.add(value);
    }

    public boolean isValid() {
        return !urls.isEmpty();
    }

    public int lineCount() {
        return urls.size();
    }

    public int lineIndex() {
        return lineIndex;
    }

    public boolean hasMultipleLines() {
        return urls.size() > 1;
    }

    public String url() {
        return urls.isEmpty() ? "" : urls.get(lineIndex);
    }

    public void nextLine() {
        if (urls.isEmpty()) return;
        lineIndex = (lineIndex + 1) % urls.size();
    }

    public void prevLine() {
        if (urls.isEmpty()) return;
        lineIndex = (lineIndex - 1 + urls.size()) % urls.size();
    }

    public void resetLine() {
        lineIndex = 0;
    }

    public String displayName() {
        return hasMultipleLines() ? name + "  (" + urls.size() + "线)" : name;
    }
}
