package com.mitv.simplelive;

public class Channel {

    public final String name;
    public final String group;
    public final String url;
    public final String logo;

    public Channel(String name, String group, String url, String logo) {
        this.name = name == null ? "" : name;
        this.group = group == null ? "" : group;
        this.url = url == null ? "" : url;
        this.logo = logo == null ? "" : logo;
    }

    public String displayName() {
        return group.isEmpty() ? name : name;
    }

    public boolean isValid() {
        return !url.isEmpty() && (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("rtsp://") || url.startsWith("rtmp://"));
    }
}
