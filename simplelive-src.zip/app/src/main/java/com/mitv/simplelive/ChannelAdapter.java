package com.mitv.simplelive;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class ChannelAdapter extends BaseAdapter {

    private final Context context;
    private final List<Channel> items;
    private int selected = -1;

    public ChannelAdapter(Context context, List<Channel> items) {
        this.context = context;
        this.items = items;
    }

    public void setSelected(int index) {
        this.selected = index;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Channel getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) view = LayoutInflater.from(context).inflate(R.layout.item_channel, parent, false);
        TextView name = view.findViewById(R.id.channel_name);
        Channel channel = getItem(position);
        name.setText(channel.name);
        view.setSelected(position == selected);
        return view;
    }
}
