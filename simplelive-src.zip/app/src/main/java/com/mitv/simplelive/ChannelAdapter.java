package com.mitv.simplelive;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class ChannelAdapter extends BaseAdapter {

    private static final int COLOR_SELECTED = 0xFF24527A;
    private static final int COLOR_NORMAL = 0x00000000;
    private static final int TEXT_SELECTED = 0xFFFFFFFF;
    private static final int TEXT_NORMAL = 0xFFE6EDF3;

    private final Context context;
    private final List<Channel> items;
    private int selected = -1;

    public ChannelAdapter(Context context, List<Channel> items) {
        this.context = context;
        this.items = items;
    }

    public void setSelected(int index) {
        if (selected == index) return;
        selected = index;
        notifyDataSetChanged();
    }

    public int getSelected() {
        return selected;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Channel getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) view = LayoutInflater.from(context).inflate(R.layout.item_channel, parent, false);
        TextView name = view.findViewById(R.id.channel_name);
        Channel channel = getItem(position);
        name.setText(channel.displayName());
        boolean isSelected = position == selected;
        view.setBackgroundColor(isSelected ? COLOR_SELECTED : COLOR_NORMAL);
        name.setTextColor(isSelected ? TEXT_SELECTED : TEXT_NORMAL);
        return view;
    }
}
