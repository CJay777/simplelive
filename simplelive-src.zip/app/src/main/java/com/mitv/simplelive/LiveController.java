package com.mitv.simplelive;

import android.content.Context;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

/**
 * 三播放器直播控制器。
 * 前台播放当前频道；后台两个播放器分别预载「上一个 / 下一个」频道。
 * 预载状态按 URL 快照记录，切换线路不会污染预载判断。
 */
public class LiveController {

    public interface Listener {
        void onChannelPlayed(Channel channel);

        void onLoading(boolean loading);

        void onError(String message);
    }

    private static final int SLOTS = 3;

    private final PlayerView[] views = new PlayerView[SLOTS];
    private final ExoPlayer[] players = new ExoPlayer[SLOTS];
    private final String[] preparedUrls = new String[SLOTS];
    private final Listener listener;

    private int front;
    private boolean released;
    private Channel current;
    private String currentUrl;
    private Channel pending;
    private String pendingUrl;
    private int pendingSlot = -1;

    public LiveController(Context context, PlayerView viewA, PlayerView viewB, PlayerView viewC, Listener listener) {
        this.listener = listener;
        this.views[0] = viewA;
        this.views[1] = viewB;
        this.views[2] = viewC;
        for (int i = 0; i < SLOTS; i++) {
            DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                    .setBufferDurationsMs(2000, 8000, 1000, 2000)
                    .build();
            players[i] = new ExoPlayer.Builder(context).setLoadControl(loadControl).build();
            views[i].setPlayer(players[i]);
            views[i].setAlpha(i == 0 ? 1f : 0f);
            players[i].addListener(new PlayerEvents(i));
        }
    }

    private ExoPlayer frontPlayer() {
        return players[front];
    }

    public Channel getCurrent() {
        return current;
    }

    public void playFirst(Channel channel) {
        if (channel == null || released) return;
        ExoPlayer player = players[front];
        player.stop();
        player.clearMediaItems();
        player.setMediaItem(toMediaItem(channel.url()));
        player.setPlayWhenReady(true);
        player.prepare();
        current = channel;
        currentUrl = channel.url();
        listener.onLoading(true);
        listener.onChannelPlayed(channel);
    }

    public void play(Channel channel) {
        if (channel == null || released) return;
        String url = channel.url();
        if (pending != null && url.equals(pendingUrl)) return;
        if (pending == null && url.equals(currentUrl)) return;
        for (int i = 0; i < SLOTS; i++) {
            if (i == front || preparedUrls[i] == null) continue;
            if (preparedUrls[i].equals(url) && players[i].getPlaybackState() >= Player.STATE_BUFFERING) {
                pending = null;
                pendingSlot = -1;
                activate(i, channel);
                return;
            }
        }
        int slot = (front + 1) % SLOTS;
        pending = channel;
        pendingUrl = url;
        pendingSlot = slot;
        preparedUrls[slot] = null;
        ExoPlayer player = players[slot];
        player.stop();
        player.clearMediaItems();
        player.setMediaItem(toMediaItem(url));
        player.setPlayWhenReady(false);
        player.prepare();
        listener.onLoading(true);
    }

    public void preload(Channel prev, Channel next) {
        if (released || pending != null) return;
        loadTo((front + 1) % SLOTS, next);
        loadTo((front + 2) % SLOTS, prev);
    }

    private void loadTo(int slot, Channel channel) {
        if (slot == front || pendingSlot == slot) return;
        if (channel == null || channel.url().isEmpty()) return;
        String url = channel.url();
        if (url.equals(currentUrl)) return;
        if (url.equals(preparedUrls[slot])) return;
        preparedUrls[slot] = url;
        ExoPlayer player = players[slot];
        player.stop();
        player.clearMediaItems();
        player.setMediaItem(toMediaItem(url));
        player.setPlayWhenReady(false);
        player.prepare();
    }

    private void activate(int slot, Channel channel) {
        if (slot == front) return;
        ExoPlayer old = players[front];
        ExoPlayer target = players[slot];
        old.setPlayWhenReady(false);
        old.stop();
        target.setPlayWhenReady(true);
        target.play();
        views[front].setAlpha(0f);
        views[slot].setAlpha(1f);
        front = slot;
        preparedUrls[slot] = null;
        pending = null;
        pendingUrl = null;
        pendingSlot = -1;
        current = channel;
        currentUrl = channel.url();
        listener.onLoading(false);
        listener.onChannelPlayed(channel);
    }

    public void pause() {
        if (!released && frontPlayer().isPlaying()) frontPlayer().pause();
    }

    public void resume() {
        if (!released && current != null && !frontPlayer().isPlaying()) frontPlayer().play();
    }

    public void release() {
        released = true;
        for (int i = 0; i < SLOTS; i++) {
            views[i].setPlayer(null);
            players[i].release();
        }
    }

    private MediaItem toMediaItem(String url) {
        MediaItem.Builder builder = new MediaItem.Builder().setUri(url);
        if (url.toLowerCase().contains(".m3u8")) builder.setMimeType(MimeTypes.APPLICATION_M3U8);
        return builder.build();
    }

    private class PlayerEvents implements Player.Listener {

        private final int slot;

        PlayerEvents(int slot) {
            this.slot = slot;
        }

        @Override
        public void onPlaybackStateChanged(int state) {
            if (slot == front) {
                if (state == Player.STATE_READY) listener.onLoading(false);
                return;
            }
            if (pendingSlot != slot || pending == null) return;
            if (state == Player.STATE_READY) {
                activate(slot, pending);
            } else if (state == Player.STATE_BUFFERING) {
                listener.onLoading(true);
            }
        }

        @Override
        public void onPlayerError(PlaybackException error) {
            if (slot == front) listener.onLoading(false);
            if (slot == pendingSlot) {
                pending = null;
                pendingUrl = null;
                pendingSlot = -1;
                preparedUrls[slot] = null;
                listener.onLoading(false);
            }
            String name = error.getErrorCodeName();
            listener.onError(name == null ? "播放失败" : name);
        }
    }
}
