package com.mitv.simplelive;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.analytics.AnalyticsListener;
import androidx.media3.ui.PlayerView;

/**
 * 三播放器直播控制器。
 * 前台播放当前频道；后台两个播放器分别预载「上一个 / 下一个」频道。
 * 预载状态按 URL 快照记录；切换时等新播放器真正渲染出首帧才交换画面，
 * 避免「黑一下」。
 */
public class LiveController {

    public interface Listener {
        void onChannelPlayed(Channel channel);

        void onSwitching(Channel channel);

        void onLoading(boolean loading);

        void onError(String message);
    }

    private static final int SLOTS = 3;
    private static final long FIRST_FRAME_TIMEOUT_MS = 900;

    private final PlayerView[] views = new PlayerView[SLOTS];
    private final ExoPlayer[] players = new ExoPlayer[SLOTS];
    private final String[] preparedUrls = new String[SLOTS];
    private final boolean[] rendered = new boolean[SLOTS];
    private final Listener listener;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private int front;
    private boolean released;
    private Channel current;
    private String currentUrl;
    private Channel pending;
    private String pendingUrl;
    private int pendingSlot = -1;
    private int awaitingFrameSlot = -1;
    private int awaitingFrameFrom = -1;
    private static final long STALL_TIMEOUT_MS = 10000;
    private final Runnable stallWatch = () -> {
        if (pending == null && frontPlayer().getPlaybackState() == Player.STATE_BUFFERING) {
            listener.onError("卡顿超时，尝试换线");
        }
    };

    public LiveController(Context context, PlayerView viewA, PlayerView viewB, PlayerView viewC, Listener listener) {
        this.listener = listener;
        this.views[0] = viewA;
        this.views[1] = viewB;
        this.views[2] = viewC;
        for (int i = 0; i < SLOTS; i++) {
            DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                    .setBufferDurationsMs(2000, 6000, 1000, 2000)
                    .build();
            players[i] = new ExoPlayer.Builder(context).setLoadControl(loadControl).build();
            views[i].setPlayer(players[i]);
            views[i].setAlpha(i == 0 ? 1f : 0f);
            players[i].addListener(new PlayerEvents(i));
            final int slot = i;
            players[i].addAnalyticsListener(new AnalyticsListener() {
                @Override
                public void onRenderedFirstFrame(EventTime eventTime, @Nullable Object output, Format videoFormat) {
                    rendered[slot] = true;
                    if (awaitingFrameSlot == slot) applySwitch();
                }
            });
        }
    }

    private ExoPlayer frontPlayer() {
        return players[front];
    }

    public Channel getCurrent() {
        return current;
    }

    public void playFirst(Channel channel) {
        if (channel == null || released) return;
        ExoPlayer player = players[front];
        player.stop();
        player.clearMediaItems();
        player.setMediaItem(toMediaItem(channel.url()));
        player.setPlayWhenReady(true);
        player.prepare();
        current = channel;
        currentUrl = channel.url();
        listener.onSwitching(channel);
        listener.onLoading(true);
        listener.onChannelPlayed(channel);
    }

    public void play(Channel channel) {
        if (channel == null || released) return;
        String url = channel.url();
        if (pending != null && url.equals(pendingUrl)) return;
        if (pending == null && url.equals(currentUrl)) return;
        for (int i = 0; i < SLOTS; i++) {
            if (i == front || preparedUrls[i] == null) continue;
            if (!preparedUrls[i].equals(url)) continue;
            int state = players[i].getPlaybackState();
            if (state == Player.STATE_READY) {
                pending = null;
                pendingUrl = null;
                pendingSlot = -1;
                beginActivate(i, channel, true);
                return;
            }
            if (state == Player.STATE_BUFFERING) {
                pending = channel;
                pendingUrl = url;
                pendingSlot = i;
                listener.onSwitching(channel);
                listener.onLoading(true);
                return;
            }
        }
        int slot = (front + 1) % SLOTS;
        pending = channel;
        pendingUrl = url;
        pendingSlot = slot;
        preparedUrls[slot] = null;
        rendered[slot] = false;
        listener.onSwitching(channel);
        listener.onLoading(true);
        ExoPlayer player = players[slot];
        player.stop();
        player.clearMediaItems();
        player.setMediaItem(toMediaItem(url));
        player.setPlayWhenReady(false);
        player.prepare();
    }

    public void preload(Channel prev, Channel next) {
        if (released || pending != null) return;
        loadTo((front + 1) % SLOTS, next);
        loadTo((front + 2) % SLOTS, prev);
    }

    private void loadTo(int slot, Channel channel) {
        if (slot == front || pendingSlot == slot) return;
        if (channel == null || channel.url().isEmpty()) return;
        String url = channel.url();
        if (url.equals(currentUrl)) return;
        if (url.equals(preparedUrls[slot])) return;
        preparedUrls[slot] = url;
        rendered[slot] = false;
        ExoPlayer player = players[slot];
        player.stop();
        player.clearMediaItems();
        player.setMediaItem(toMediaItem(url));
        player.setPlayWhenReady(false);
        player.prepare();
    }

    private void beginActivate(int slot, Channel channel, boolean hitPreload) {
        ExoPlayer old = players[front];
        ExoPlayer target = players[slot];
        target.setPlayWhenReady(true);
        target.play();
        old.setPlayWhenReady(false);
        old.stop();
        int oldFront = front;
        front = slot;
        preparedUrls[slot] = null;
        pending = null;
        pendingUrl = null;
        pendingSlot = -1;
        current = channel;
        currentUrl = channel.url();
        if (rendered[slot]) {
            applySwitchNow(slot);
            listener.onLoading(false);
        } else {
            awaitingFrameSlot = slot;
            awaitingFrameFrom = oldFront;
            handler.postDelayed(() -> {
                if (awaitingFrameSlot == slot) applySwitch();
            }, FIRST_FRAME_TIMEOUT_MS);
        }
        listener.onChannelPlayed(channel);
    }

    private void applySwitch() {
        int slot = awaitingFrameSlot;
        awaitingFrameSlot = -1;
        awaitingFrameFrom = -1;
        if (slot >= 0) applySwitchNow(slot);
        listener.onLoading(false);
    }

    private void applySwitchNow(int to) {
        for (int i = 0; i < SLOTS; i++) views[i].setAlpha(i == to ? 1f : 0f);
    }

    public void pause() {
        if (!released && frontPlayer().isPlaying()) frontPlayer().pause();
    }

    public void resume() {
        if (!released && current != null && !frontPlayer().isPlaying()) frontPlayer().play();
    }

    public void release() {
        released = true;
        handler.removeCallbacks(stallWatch);
        handler.removeCallbacksAndMessages(null);
        for (int i = 0; i < SLOTS; i++) {
            views[i].setPlayer(null);
            players[i].release();
        }
    }

    private MediaItem toMediaItem(String url) {
        MediaItem.Builder builder = new MediaItem.Builder().setUri(url);
        if (url.toLowerCase().contains(".m3u8")) builder.setMimeType(MimeTypes.APPLICATION_M3U8);
        return builder.build();
    }

    private class PlayerEvents implements Player.Listener {

        private final int slot;

        PlayerEvents(int slot) {
            this.slot = slot;
        }

        @Override
        public void onPlaybackStateChanged(int state) {
            if (slot == front) {
                handler.removeCallbacks(stallWatch);
                if (state == Player.STATE_READY) {
                    listener.onLoading(false);
                } else if (state == Player.STATE_BUFFERING && pending == null) {
                    handler.postDelayed(stallWatch, STALL_TIMEOUT_MS);
                }
                return;
            }
            if (pendingSlot != slot || pending == null) return;
            if (state == Player.STATE_READY) {
                beginActivate(slot, pending, false);
            } else if (state == Player.STATE_BUFFERING) {
                listener.onLoading(true);
            }
        }

        @Override
        public void onPlayerError(PlaybackException error) {
            if (slot == front) listener.onLoading(false);
            if (slot == pendingSlot) {
                pending = null;
                pendingUrl = null;
                pendingSlot = -1;
                preparedUrls[slot] = null;
                frontPlayer().setPlayWhenReady(true);
                listener.onLoading(false);
            }
            String name = error.getErrorCodeName();
            listener.onError(name == null ? "播放失败" : name);
        }
    }
}
