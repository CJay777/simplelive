package com.mitv.simplelive;

import java.util.ArrayList;
import java.util.List;

public class M3uParser {

    public static List<Channel> parse(String content) {
        List<Channel> list = new ArrayList<>();
        if (content == null) return list;
        String name = null;
        String group = "";
        String logo = "";
        for (String raw : content.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF")) {
                name = afterComma(line);
                group = attr(line, "group-title");
                logo = attr(line, "tvg-logo");
            } else if (!line.startsWith("#") && name != null) {
                Channel channel = new Channel(name, group, line, logo);
                if (channel.isValid()) list.add(channel);
                name = null;
                group = "";
                logo = "";
            }
        }
        return list;
    }

    private static String afterComma(String line) {
        int index = line.lastIndexOf(',');
        return index < 0 ? "" : line.substring(index + 1).trim();
    }

    private static String attr(String line, String key) {
        String prefix = key + "=\"";
        int start = line.indexOf(prefix);
        if (start < 0) return "";
        start += prefix.length();
        int end = line.indexOf('"', start);
        return end < 0 ? "" : line.substring(start, end);
    }
}
