package com.mitv.simplelive;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class M3uParser {

    /**
     * 解析 m3u：同名频道合并为一条，多个地址作为该频道的不同线路。
     */
    public static List<Channel> parse(String content) {
        List<Channel> result = new ArrayList<>();
        if (content == null) return result;
        Map<String, Channel> merged = new LinkedHashMap<>();
        String name = null;
        String group = "";
        String logo = "";
        for (String raw : content.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF")) {
                name = afterComma(line);
                group = attr(line, "group-title");
                logo = attr(line, "tvg-logo");
            } else if (!line.startsWith("#") && name != null) {
                Channel channel = merged.get(name);
                if (channel == null) {
                    channel = new Channel(name, group, logo);
                    merged.put(name, channel);
                }
                channel.addUrl(line);
                name = null;
                group = "";
                logo = "";
            }
        }
        for (Channel channel : merged.values()) {
            if (channel.isValid()) result.add(channel);
        }
        return result;
    }

    private static String afterComma(String line) {
        int index = line.lastIndexOf(',');
        return index < 0 ? "" : line.substring(index + 1).trim();
    }

    private static String attr(String line, String key) {
        String prefix = key + "=\"";
        int start = line.indexOf(prefix);
        if (start < 0) return "";
        start += prefix.length();
        int end = line.indexOf('"', start);
        return end < 0 ? "" : line.substring(start, end);
    }
}
